let romaarak = 22000;
let romaszazalek = 12;
let jordanarak = 42500;
let jordanszazalek = 16;
let torokarak = 39500;
let torokszazalek = 13;
let marokkoarak = 376000;
let marokkoszazalek = 17;

document.getElementById("romaar").value = romaarak;
document.getElementById("roma%").value = romaszazalek;
document.getElementById("romaossz").value = 0;
document.getElementById("jordanar").value = jordanarak;
document.getElementById("jordan%").value = jordanszazalek;
document.getElementById("jordanossz").value = 0;
document.getElementById("torokar").value = torokarak;
document.getElementById("torok%").value = torokszazalek;
document.getElementById("torokossz").value = 0;
document.getElementById("marokkoar").value = marokkoarak;
document.getElementById("marokko%").value = marokkoszazalek;
document.getElementById("marokkoossz").value = 0;
document.getElementById("ossz").value = getElementById("romaossz").value + getElementById("jordanossz").value +getElementById("torokossz").value + getElementById("marokkoossz").value;

function roma() {
    let romaosszeg = romaarak * (romaszazalek / 100) * getElementById("romafo").value;
    if (getElementById("romacheck").value = true) {
        romaosszeg * 1,12
        getElementById("romaossz").value = romaosszeg
    }
    else {
    getElementById("romaossz").value = romaosszeg;
    }
}
